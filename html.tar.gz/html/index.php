
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta http-equiv="x-ua-compatible" content="ie=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Welcome OpenVPN by HFN</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.4.3/css/foundation.min.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet" />
<style type="text/css">* { font-family: 'Source Sans Pro', sans-serif; }
body { background: #73c6c3; background: -moz-linear-gradient(-45deg,  #73c6c3 0%, #5e9e9b 100%); background: -webkit-linear-gradient(-45deg,  #73c6c3 0%,#5e9e9b 100%); background: linear-gradient(135deg,  #73c6c3 0%,#5e9e9b 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#73c6c3', endColorstr='#5e9e9b',GradientType=1 ); }
h1 { font-weight: bold; }
h3 {font-size: 18px;}
h4 {font-size: 14px;}
p { font-size: 20px; }
.text { font-family: "Times New Roman", Times, serif;}
.callout { margin: 0; border: 1px solid #777; box-shadow: 3px 3px 10px #777; }
.button {  border: none;  color: white;  padding: 16px 32px;  text-align: center;  text-decoration: none;  display: inline-block;  font-size: 16px;  margin: 4px 2px;  transition-duration: 0.4s;  cursor: pointer;
}
.button1 {  background-color: white;   color: black;  border: 2px solid #4CAF50;}
.button1:hover {  background-color: #4CAF50;  color: white;}
.button2 {  background-color: white;   color: black;  border: 2px solid #008CBA;}
.button2:hover {  background-color: #008CBA;  color: white;}
.g-recaptcha{  margin: 0px auto !important;  width: auto !important;  height: auto !important;  text-align: -webkit-center;  text-align: -moz-center; text-align: -o-center;  text-align: -ms-center;}
</style>
<script src="https://www.google.com/recaptcha/api.js"></script>
</head>
<body>
<div class="grid-container fluid">
<div class="grid-y grid-margin-x align-middle align-center large-grid-frame" style="min-height: 100vh">
<div class="cell large-cell-block-container">
<div class="grid-x align-center">
<div class="cell small-12 medium-10 large-6 text-center">
<div class="callout alert">
<h1 id="seed-csp4-headline">Welcome OpenVPN by HFN!</h1>
<p class="text"> <h4>Your online activity is your business.<br>
OpenVPN by HFN masks your IP address and encrypts your data on any network, even public Wi-Fi.<br>
Start reclaiming your anonymity in seconds.</h4>
</p>
<p><h3>Verifying that you are not a robot...</h3>
    <form action="" method="POST">
        <div class="g-recaptcha d-inline-block" data-sitekey="6LdZB5cUAAAAADNXnFkyqoeIiJjCDexVZgqX47sy"></div>
      <br/>
      <input class="button button1" type=submit value="Submit">
    </form></p>
<?php
$session_url="../trial/";
$secret = "6LdZB5cUAAAAADAq-bhXAX3L1RgfnYo2g2Ow9tqg";
$post = [
    'secret' => $secret,
    'response' => $_POST['g-recaptcha-response'],
    'remoteip'   => $_SERVER['REMOTE_ADDR']
];
$ch = curl_init('https://www.google.com/recaptcha/api/siteverify');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
$response = curl_exec($ch);
curl_close($ch);
//var_dump(json_decode($response)); 
$array = json_decode($response,true);
//echo "<pre/>";print_r($array);
if($array['success'] == 1){
   echo("<script>location.href = '$session_url';</script>");
} else{
echo "Confirm for a new registration request!";
}
?>
<p><h4>I already have an account created...</h4></p>
<p><a href="../check.html"><button class="button button2">Check Status Account</button></a></p>
</div>
<p>&copy; 2023 OpenVPN by <a href="//www.hfn.ee" title="script auto register openvpn">HostingFuze Network</a>. All rights reserved.</p>
</div>
</div>
</div>
</div>
</div>
</body>
</html>