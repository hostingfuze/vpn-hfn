<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta http-equiv="x-ua-compatible" content="ie=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Email Confirmation - OpenVPN - Trial!</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.4.3/css/foundation.min.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet" />
<style type="text/css">* { font-family: 'Source Sans Pro', sans-serif; }
body { background: #73c6c3; background: -moz-linear-gradient(-45deg,  #73c6c3 0%, #5e9e9b 100%); background: -webkit-linear-gradient(-45deg,  #73c6c3 0%,#5e9e9b 100%); background: linear-gradient(135deg,  #73c6c3 0%,#5e9e9b 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#73c6c3', endColorstr='#5e9e9b',GradientType=1 ); }
h1 { font-weight: bold; }
p { font-size: 26px; }
.callout { margin: 0; border: 1px solid #777; box-shadow: 3px 3px 10px #777; }
.button {  border: none;  color: white;  padding: 16px 32px;  text-align: center;  text-decoration: none;  display: inline-block;  font-size: 16px;  margin: 4px 2px;  transition-duration: 0.4s;  cursor: pointer;
}
.button1 {  background-color: white;   color: black;  border: 2px solid #4CAF50;}
.button1:hover {  background-color: #4CAF50;  color: white;}
</style>
</head>
<body>
<div class="grid-container fluid">
<div class="grid-y grid-margin-x align-middle align-center large-grid-frame" style="min-height: 100vh">
<div class="cell large-cell-block-container">
<div class="grid-x align-center">
<div class="cell small-12 medium-10 large-6 text-center">
<div class="callout alert">
<h1 id="seed-csp4-headline">Email Confirmation</h1>
<p>
<?php
$email = $_REQUEST['email'];
$code = $_REQUEST['code'];
$output = shell_exec("/usr/local/lsws/Example/html/trial/confirm_email.sh $email $code");
//echo $output;
echo "<pre>$output</pre>";
?>
</p>
</div>
<p>&copy; 2023 OpenVPN by <a href="//www.hfn.ee" title="script auto register openvpn">HostingFuze Network</a>. All rights reserved.</p>
</div>
</div>
</div>
</div>
</div>
</body>
</html>