<?php
$user = $_REQUEST['adminUser'];
$pass = $_REQUEST['adminPass'];
if (empty($user)) {
 echo '{"error_message": "User is empty."}';
} else {
if (empty($pass)) {
 echo '{"error_message": "Password is empty."}';
} else {
$output = shell_exec("/usr/local/lsws/Example/html/api/verify.sh $user $pass");
echo "$output";  
}
} 
?>