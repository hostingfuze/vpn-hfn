<?php
$user = $_REQUEST['adminUser'];
$pass = $_REQUEST['adminPass'];
$username = $_REQUEST['username'];
if (empty($user)) {
 echo '{"error_message": "User is empty."}';
} else {
if (empty($pass)) {
 echo '{"error_message": "Password is empty."}';
} else {
$output = shell_exec("/usr/local/lsws/Example/html/api/revoke.sh $user $pass $username");
echo "$output";  
}
} 
?>
