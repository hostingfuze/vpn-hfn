<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta http-equiv="x-ua-compatible" content="ie=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quarterly Plan!</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.4.3/css/foundation.min.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet" />
<style type="text/css">* { font-family: 'Source Sans Pro', sans-serif; }
body { background: #73c6c3; background: -moz-linear-gradient(-45deg,  #73c6c3 0%, #5e9e9b 100%); background: -webkit-linear-gradient(-45deg,  #73c6c3 0%,#5e9e9b 100%); background: linear-gradient(135deg,  #73c6c3 0%,#5e9e9b 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#73c6c3', endColorstr='#5e9e9b',GradientType=1 ); }
h1 { font-weight: bold; }
p { font-size: 26px; }
.callout { margin: 0; border: 1px solid #777; box-shadow: 3px 3px 10px #777; }
.button {  border: none;  color: white;  padding: 16px 32px;  text-align: center;  text-decoration: none;  display: inline-block;  font-size: 16px;  margin: 4px 2px;  transition-duration: 0.4s;  cursor: pointer;
}
.button1 {  background-color: white;   color: black;  border: 2px solid #4CAF50;}
.button1:hover {  background-color: #4CAF50;  color: white;}
.button2 {  background-color: white;   color: black;  border: 2px solid #008CBA;}
.button2:hover {  background-color: #008CBA;  color: white;}
.button3 {  background-color: white;   color: black;  border: 3px solid #ba0003;}
.button3:hover {  background-color: #ba0079;  color: white;}
</style>
</head>
<body>
<div class="grid-container fluid">
<div class="grid-y grid-margin-x align-middle align-center large-grid-frame" style="min-height: 100vh">
<div class="cell large-cell-block-container">
<div class="grid-x align-center">
<div class="cell small-12 medium-10 large-6 text-center">
<div class="callout alert">
<?php $user = $_REQUEST['user']; if (empty($user)) { ?>
<h1 id="seed-csp4-headline">Error ...</h1>
<p><a href="../admin/trial.php"><button class="button button1">Try Again</button></a></p>
<p><?php die("Username is empty"); } ?></p>
<p><a href="../admin/index.php"><button class="button button2">Home</button></a> 
<a href="../admin/trial.php"><button class="button button2">View Trial List</button></a>
<a href="../admin/user.php"><button class="button button2">View Payment List</button></a>
</p>
<h1 id="seed-csp4-headline">I will add the quarterly plan for the user:</h1>
<h3> [ <?php $user = $_REQUEST['user']; echo $user; ?> ]</h3>
<p> If you agree with this please confirm...<br/>
<form method="post" action="<?php echo $_SERVER['REQUEST_URI'];?>">
<input type="submit" name="quantity" class="button button1" value="Confirm">
</form>

 
</p>
<p>
    <?php
              
        if ($_SERVER["REQUEST_METHOD"]=="POST") {
            $quantity = htmlspecialchars($_REQUEST['quantity']); 
            $user = $_REQUEST['user'];
            // Collecting the value of input field from it
            if (empty($quantity)) {
                echo "Please Confirm";
            } 
            else {
               $output = shell_exec("/usr/local/lsws/Example/html/protected/update.sh $user quarterly");
echo "<pre>$output</pre>";
echo "I'll be out of here in 2 seconds...";
header( "refresh:3; url=index.php" );
           }
        }
    ?>
</p>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>