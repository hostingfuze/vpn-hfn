<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta http-equiv="x-ua-compatible" content="ie=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>List - Payment!</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/foundation/6.4.3/css/foundation.min.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet" />
<style type="text/css">* { font-family: 'Source Sans Pro', sans-serif; }
body { background: #73c6c3; background: -moz-linear-gradient(-45deg,  #73c6c3 0%, #5e9e9b 100%); background: -webkit-linear-gradient(-45deg,  #73c6c3 0%,#5e9e9b 100%); background: linear-gradient(135deg,  #73c6c3 0%,#5e9e9b 100%); filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#73c6c3', endColorstr='#5e9e9b',GradientType=1 ); }
h1 { font-weight: bold; }
p { font-size: 26px; }
.callout { margin: 0; border: 1px solid #777; box-shadow: 3px 3px 10px #777; }
.button {  border: none;  color: white;  padding: 16px 32px;  text-align: center;  text-decoration: none;  display: inline-block;  font-size: 16px;  margin: 4px 2px;  transition-duration: 0.4s;  cursor: pointer;
}
.button1 {  background-color: white;   color: black;  border: 2px solid #4CAF50;}
.button1:hover {  background-color: #4CAF50;  color: white;}
.button2 {  background-color: white;   color: black;  border: 2px solid #008CBA;}
.button2:hover {  background-color: #008CBA;  color: white;}
.button3 {  background-color: white;   color: black;  border: 3px solid #ba0003;}
.button3:hover {  background-color: #ba0079;  color: white;}
</style>
</head>
<body>
<div class="grid-container fluid">
<div class="grid-y grid-margin-x align-middle align-center large-grid-frame" style="min-height: 100vh">
<div class="cell large-cell-block-container">
<div class="grid-x align-center">
<div class="cell small-12 medium-10 large-6 text-center">
<div class="callout alert">
<p><a href="../admin/index.php"><button class="button button2">Home</button></a></p>
<h1 id="seed-csp4-headline">View Users List</h1>
<p>
<?php
$output = shell_exec("/usr/local/lsws/Example/html/protected/users.sh");
echo "<pre>$output</pre>";
$search="There are no customers for the paid service!";
if(preg_match("/{$search}/i", $output)) {
?></p><p> More action is needed... Courage!</p>
<?php
} else { ?>
<form action="../admin/custom.php">
  <label for="txt_1">Add a username without "[ ]" and select one of the buttons below :</label>
  <input type="text" id="user" name="user"><br><br>
  <label for="txt_2">Add the validity period:</label>
  <input type="submit" class="button button1" value="Custom">
  <input type="submit" formaction="../admin/monthly.php" class="button button1" value="Monthly">
  <input type="submit" formaction="../admin/quarterly.php" class="button button1" value="Quarterly">
  <input type="submit" formaction="../admin/semi-annually.php" class="button button1" value="Semi-Annually">
  <input type="submit" formaction="../admin/annually.php" class="button button1" value="Annually">  
  <input type="submit" formaction="../admin/unlimited.php" class="button button1" value="Unlimited">
  <label for="txt_3">Revoke username:</label>
  <input type="submit" formaction="../admin/revoke.php" class="button button3" value="Revoke">
</form>
</p>
<p>
<?php
$output = shell_exec("/usr/local/lsws/Example/html/protected/plans.sh");
echo "<pre>$output</pre>";
echo "Unlimited = 10 years";
}?>
</p>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>